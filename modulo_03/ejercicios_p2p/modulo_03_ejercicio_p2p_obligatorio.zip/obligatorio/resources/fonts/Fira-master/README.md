See http://www.carrois.com/fira-3-1/ for more details.

Use this font on your website!

```html
<link rel="stylesheet" href="//code.cdn.mozilla.net/fonts/fira.css">
```
